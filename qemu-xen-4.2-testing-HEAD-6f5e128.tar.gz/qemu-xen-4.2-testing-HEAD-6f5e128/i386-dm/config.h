#include "../config-host.h"
#define CONFIG_QEMU_PREFIX ""
#define TARGET_ARCH "i386"
#define TARGET_I386 1
#define CONFIG_SOFTMMU 1
#define CONFIG_SOFTFLOAT 1
